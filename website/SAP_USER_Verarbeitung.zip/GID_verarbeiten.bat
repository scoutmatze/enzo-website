@echo off
chcp 65001 >nul
title GID Processor – SAP User Count Aggregation

echo.
echo ============================================================
echo   GID Processor – SAP User Count Aggregation
echo   Siemens IT ECP
echo ============================================================
echo.

:: ── EINSTELLUNG: Dateiname deines SAP-Exports ────────────────────────────────
:: Passe diese Zeile an – entweder fixer Name oder * für automatische Suche
set EXPORT_DATEI=SAP_User_Export.xlsx

:: Unique-Schalter: ja = Duplikate pro SID ignorieren (empfohlen)
set UNIQUE=ja

:: ── Automatische Suche falls Dateiname nicht passt ───────────────────────────
if not exist "%EXPORT_DATEI%" (
    echo  ⚠  Datei "%EXPORT_DATEI%" nicht gefunden.
    echo.
    echo  Suche nach Excel-Dateien im aktuellen Ordner...
    echo.
    set FOUND=0
    for %%f in (*.xlsx *.xls *.csv) do (
        if not "%%f"=="GID_Aggregiert_*.xlsx" (
            if not "%%f"=="gid_processor.py" (
                echo  Gefunden: %%f
                set EXPORT_DATEI=%%f
                set FOUND=1
            )
        )
    )
    if "%FOUND%"=="0" (
        echo  ✗ Keine Excel- oder CSV-Datei gefunden.
        echo    Lege deine SAP-Export-Datei in diesen Ordner:
        echo    %~dp0
        echo.
        pause
        exit /b 1
    )
    echo.
    echo  Verwende: %EXPORT_DATEI%
    echo.
)

:: ── Python-Verfügbarkeit prüfen ───────────────────────────────────────────────
python --version >nul 2>&1
if errorlevel 1 (
    echo  ✗ Python nicht gefunden.
    echo.
    echo  Bitte Python installieren:
    echo  1. https://python.org/downloads aufrufen
    echo  2. "Download Python 3.x" klicken
    echo  3. Installieren – WICHTIG: Haken bei "Add Python to PATH" setzen
    echo  4. Danach diese Datei nochmal starten
    echo.
    pause
    exit /b 1
)

:: ── Abhängigkeiten prüfen und installieren ────────────────────────────────────
echo  Prüfe Abhängigkeiten (pandas, openpyxl)...
python -c "import pandas, openpyxl" >nul 2>&1
if errorlevel 1 (
    echo  → Installiere pandas und openpyxl (einmalig, ~30 Sekunden)...
    echo.
    pip install pandas openpyxl --quiet
    if errorlevel 1 (
        echo  ✗ Installation fehlgeschlagen. Bitte manuell ausführen:
        echo    pip install pandas openpyxl
        echo.
        pause
        exit /b 1
    )
    echo  ✓ Installation erfolgreich
    echo.
)

:: ── Skript-Verfügbarkeit prüfen ───────────────────────────────────────────────
if not exist "gid_processor.py" (
    echo  ✗ gid_processor.py nicht gefunden.
    echo    Lege gid_processor.py in den gleichen Ordner wie diese .bat Datei:
    echo    %~dp0
    echo.
    pause
    exit /b 1
)

:: ── Verarbeitung starten ──────────────────────────────────────────────────────
echo  Starte Verarbeitung...
echo  Export-Datei:    %EXPORT_DATEI%
echo  Unique-Schalter: %UNIQUE%
echo.
echo  (Bitte warten – bei großen Dateien kann das 1-2 Minuten dauern)
echo.

python gid_processor.py "%EXPORT_DATEI%" --unique-schalter %UNIQUE%

if errorlevel 1 (
    echo.
    echo  ✗ Fehler bei der Verarbeitung.
    echo    Fehlermeldung oben lesen – häufige Ursachen:
    echo    - Spaltenname GID/SID/Position anders als erwartet
    echo    - Datei ist noch in Excel geöffnet (schließen und nochmal)
    echo    - Dateiformat nicht unterstützt
    echo.
    echo  Tipp: Spalten manuell angeben:
    echo    python gid_processor.py "%EXPORT_DATEI%" --col-gid GID --col-sid SID --col-position Position
    echo.
    pause
    exit /b 1
)

echo.
echo ============================================================
echo   ✓ Fertig!
echo ============================================================
echo.
echo  Die Ergebnis-Datei liegt im gleichen Ordner:
echo  %~dp0
echo.
echo  NÄCHSTE SCHRITTE:
echo  1. GID_Aggregiert_*.xlsx öffnen
echo  2. Tab "GID_Aggregiert" → Spalte G (grün, EMPFOHLEN) kopieren
echo  3. Simulation_Sc1 → Zielzelle → Rechtsklick
echo     → "Inhalte einfügen" → "Werte" (NICHT normale Einfügen!)
echo  4. Fertig – Excel rechnet nicht mehr neu bis zur nächsten Erhebung
echo.

:: Ergebnis-Datei automatisch öffnen
echo  Ergebnis-Datei wird geöffnet...
for %%f in (GID_Aggregiert_*.xlsx) do (
    start "" "%%f"
    goto :opened
)
:opened

pause
