#!/usr/bin/env python3
"""
GID Data Processor – SAP User Count Aggregation
================================================
Input:  Raw SAP user export (Excel oder CSV)
        Relevante Spalten: GID, SID, Position (=ARE_Business_BusinessUnit)
        Ignoriert: leere Position, "ARE_notallocated"

Output: GID_Aggregiert_[datum].xlsx  – paste-ready für Simulation_Sc1
        4 Metriken pro ARE_Business_BU:
        (1) User# per SID          – Anzahl Zeilen (inkl. Duplikate) pro SID
        (2) User# total            – Anzahl Zeilen über alle SIDs
        (3) Unique User# per SID   – distinct GIDs innerhalb SID
        (4) Unique User# total     – distinct GIDs global

Verwendung:
  python3 gid_processor.py <input_file> [--unique-schalter ja|nein]

  Beispiele:
  python3 gid_processor.py SAP_User_Export.xlsx
  python3 gid_processor.py SAP_User_Export.csv --unique-schalter ja

Ergebnis in die Simulation einkopieren:
  Tab 'GID_Aggregiert' → Tab 'Simulation_Sc1' Spalten User/SID etc.
  → Als WERTE einfügen (Strg+Shift+V oder Inhalte einfügen → Werte)
"""

import sys
import os
import argparse
from datetime import datetime

import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import (Font, PatternFill, Alignment, Border, Side,
                              GradientFill)
from openpyxl.utils import get_column_letter

# ── Siemens Brand Colors ──────────────────────────────────────────────────────
DN  = "000028"  # Deep Navy
PT  = "009999"  # Siemens Petrol
SB  = "00BEDC"  # Soft Blue
SG  = "00D7A0"  # Soft Green
DO  = "EC6602"  # Dark Orange
DY  = "F7C600"  # Yellow
WH  = "FFFFFF"
LS  = "F3F3F0"  # Light Sand
DS  = "AAAA96"  # Dark Sand
IB  = "FFF8DC"  # Input sand
TB  = "E0F5F5"  # Total petrol

# ── Filter constants ──────────────────────────────────────────────────────────
IGNORE_POSITION = {"ARE_notallocated", "are_notallocated"}
COL_ALIASES = {
    "gid":      ["GID", "Gid", "gid", "User ID", "UserID", "user_id"],
    "sid":      ["SID", "Sid", "sid", "System ID", "SystemID", "InstNo",
                 "system_id", "SAP System"],
    "position": ["Position", "position", "ARE_Business_BusinessUnit",
                 "ARE_BU", "Dept_Position", "Org_Unit"],
}

# ── Style helpers ─────────────────────────────────────────────────────────────
def fl(c): return PatternFill("solid", fgColor=c)
def fn(b=False, c="000000", sz=10, it=False):
    return Font(name="Arial", bold=b, color=c, size=sz, italic=it)
def al(h="left", v="center", w=False):
    return Alignment(horizontal=h, vertical=v, wrap_text=w)
def bd(thin=True):
    s = "thin" if thin else "medium"
    x = Side(style=s, color="CCCCCC")
    return Border(left=x, right=x, top=x, bottom=x)

def style(cell, bg=None, fg="000000", b=False, sz=10, ha="left",
          va="center", wrap=False, nf=None, it=False, border=True):
    if bg:   cell.fill = fl(bg)
    cell.font      = fn(b=b, c=fg, sz=sz, it=it)
    cell.alignment = al(h=ha, v=va, w=wrap)
    if border: cell.border = bd()
    if nf:   cell.number_format = nf

def h1(ws, r, c1, c2, text):
    ws.merge_cells(start_row=r, start_column=c1, end_row=r, end_column=c2)
    cell = ws.cell(r, c1, text)
    style(cell, bg=DN, fg=WH, b=True, sz=13, ha="center", border=False)
    thick = Side(style="medium", color="606060")
    cell.border = Border(left=thick, right=thick, top=thick, bottom=thick)
    ws.row_dimensions[r].height = 34

def h2(ws, r, c1, c2, text, bg=PT, fg=WH):
    ws.merge_cells(start_row=r, start_column=c1, end_row=r, end_column=c2)
    cell = ws.cell(r, c1, text)
    style(cell, bg=bg, fg=fg, b=True, sz=11, ha="center")
    ws.row_dimensions[r].height = 22

def ch(ws, r, c, text, bg=PT, fg=WH, sz=9):
    cell = ws.cell(r, c, text)
    style(cell, bg=bg, fg=fg, b=True, sz=sz, ha="center", wrap=True)

def note(ws, r, c1, c2, text, fg=DN, bg=None, h=22):
    ws.merge_cells(start_row=r, start_column=c1, end_row=r, end_column=c2)
    cell = ws.cell(r, c1, text)
    style(cell, fg=fg, bg=bg, it=True, wrap=True, border=False)
    ws.row_dimensions[r].height = h

def txt(ws, r, c, val, bg=None, fg="000000", b=False,
        ha="left", it=False, nf=None):
    cell = ws.cell(r, c, val)
    style(cell, bg=bg, fg=fg, b=b, ha=ha, it=it, nf=nf)
    return cell

def tot(ws, r, c, val, nf=None):
    cell = ws.cell(r, c, val)
    style(cell, bg=TB, fg=DN, b=True, nf=nf)
    return cell

F_INT = '#,##0;(#,##0);"-"'
F_PCT = '0.0%'


# ── Column detection ──────────────────────────────────────────────────────────
def find_col(df_cols, aliases):
    for alias in aliases:
        if alias in df_cols:
            return alias
    return None


# ── Core computation ──────────────────────────────────────────────────────────
def compute_metrics(df: pd.DataFrame, unique_schalter: bool) -> pd.DataFrame:
    """
    Returns a DataFrame with columns:
      ARE_Business_BU | SID |
      user_per_sid | unique_user_per_sid |
      user_total | unique_user_total
    """
    # Filter
    df = df.dropna(subset=["position"])
    df = df[~df["position"].str.strip().isin(IGNORE_POSITION)]
    df = df[df["position"].str.strip() != ""]

    # Normalise
    df["position"] = df["position"].str.strip()
    df["gid"]      = df["gid"].astype(str).str.strip()
    df["sid"]      = df["sid"].astype(str).str.strip()

    # (1) User# per SID per ARE_BU – count all rows (incl. duplicates)
    user_per_sid = (df.groupby(["position", "sid"])
                      .size()
                      .reset_index(name="user_per_sid"))

    # (3) Unique User# per SID – distinct GIDs within SID+ARE_BU
    unique_per_sid = (df.drop_duplicates(subset=["position", "sid", "gid"])
                        .groupby(["position", "sid"])
                        .size()
                        .reset_index(name="unique_user_per_sid"))

    # (2) User# total per ARE_BU – all rows across all SIDs
    user_total = (df.groupby("position")
                    .size()
                    .reset_index(name="user_total"))

    # (4) Unique User# total – distinct GIDs globally per ARE_BU
    unique_total = (df.drop_duplicates(subset=["position", "gid"])
                      .groupby("position")
                      .size()
                      .reset_index(name="unique_user_total"))

    # Merge
    result = (user_per_sid
              .merge(unique_per_sid, on=["position", "sid"], how="outer")
              .merge(user_total,     on="position",           how="left")
              .merge(unique_total,   on="position",           how="left"))

    result = result.rename(columns={"position": "ARE_Business_BU"})
    result = result.sort_values(["ARE_Business_BU", "sid"]).reset_index(drop=True)
    result["unique_schalter_aktiv"] = unique_schalter

    # Recommended user count (what the simulation uses)
    result["EMPFOHLEN_fuer_Simulation"] = (
        result["unique_user_per_sid"]
        if unique_schalter else result["user_per_sid"])

    return result


# ── Output Excel builder ──────────────────────────────────────────────────────
def build_output_excel(df_result: pd.DataFrame, source_file: str,
                       unique_schalter: bool, stats: dict) -> Workbook:
    wb = Workbook()
    wb.remove(wb.active)

    today = datetime.now().strftime("%d.%m.%Y %H:%M")
    src_name = os.path.basename(source_file)

    # ── Sheet 1: GID_Aggregiert ───────────────────────────────────────────────
    ws = wb.create_sheet("GID_Aggregiert")
    ws.sheet_view.showGridLines = False
    ws.tab_color = SG

    ws.column_dimensions["A"].width = 32  # ARE_Business_BU
    ws.column_dimensions["B"].width = 10  # SID
    ws.column_dimensions["C"].width = 16  # user_per_sid
    ws.column_dimensions["D"].width = 18  # unique_user_per_sid
    ws.column_dimensions["E"].width = 14  # user_total
    ws.column_dimensions["F"].width = 18  # unique_user_total
    ws.column_dimensions["G"].width = 22  # EMPFOHLEN

    h1(ws, 1, 1, 7, f"GID Aggregiert – {today}  |  Quelle: {src_name}")

    r = 2
    note(ws, r, 1, 7,
         f"Unique-Schalter aktiv: {'JA (Duplikate pro SID ignoriert – empfohlen)' if unique_schalter else 'NEIN (alle Zeilen gezählt)'}  |  "
         f"Ignoriert: leere Position + ARE_notallocated  |  "
         f"Gesamt ARE_BU Kombinationen: {stats['n_are_bu']:,}  |  "
         f"Gesamt SID: {stats['n_sid']:,}  |  Gesamt GIDs (roh): {stats['n_raw']:,}",
         fg=DN, h=22)
    r += 2

    note(ws, r, 1, 7,
         "⚡  Einfügen in Simulation_Sc1: Spalten C–G markieren → Kopieren → "
         "Simulation_Sc1 Tab → Zielzelle → Inhalte einfügen → NUR WERTE (Strg+Shift+V). "
         "Formeln NICHT übernehmen – nur Zahlenwerte. Dann rechnet Excel nicht mehr jedes Mal neu.",
         fg=DO, h=28)
    r += 2

    h2(ws, r, 1, 7, "Aggregierte User-Zahlen per ARE_Business_BU × SID")
    r += 1

    headers = [
        ("ARE_Business_BU",                  "A"),
        ("SID",                              "B"),
        ("(1) User# pro SID\n(alle Zeilen)", "C"),
        ("(3) Unique User#\npro SID",        "D"),
        ("(2) User# total\n(alle SIDs)",     "E"),
        ("(4) Unique User#\ntotal global",   "F"),
        ("EMPFOHLEN\nfür Simulation",        "G"),
    ]
    for i, (label, _) in enumerate(headers):
        bg = SB if i < 2 else (SG if i == 6 else PT)
        ch(ws, r, i + 1, label, bg=bg, fg=WH if i != 6 else DN)
    r += 1; data_start = r

    prev_are = None
    row_idx = 0
    are_subtotals = {}  # ARE_BU → {user_per_sid: list, ...}

    for _, row_data in df_result.iterrows():
        are  = row_data["ARE_Business_BU"]
        sid  = row_data["sid"]
        ups  = int(row_data.get("user_per_sid", 0) or 0)
        uups = int(row_data.get("unique_user_per_sid", 0) or 0)
        ut   = int(row_data.get("user_total", 0) or 0)
        uut  = int(row_data.get("unique_user_total", 0) or 0)
        emp  = int(row_data.get("EMPFOHLEN_fuer_Simulation", 0) or 0)

        bg = LS if row_idx % 2 == 0 else WH
        txt(ws, r, 1, are,  bg=bg, fg=DN, b=True)
        txt(ws, r, 2, sid,  bg=bg, fg=PT, b=True)
        txt(ws, r, 3, ups,  bg=bg, ha="center", nf=F_INT)
        txt(ws, r, 4, uups, bg=bg, ha="center", nf=F_INT)
        txt(ws, r, 5, ut,   bg=bg, ha="center", nf=F_INT)
        txt(ws, r, 6, uut,  bg=bg, ha="center", nf=F_INT)
        # Highlight recommended column
        emp_cell = ws.cell(r, 7, emp)
        style(emp_cell, bg="E8F8F0", fg="006633", b=True, ha="center", nf=F_INT)

        r += 1; row_idx += 1

    data_end = r - 1

    # Grand total row
    r += 1
    txt(ws, r, 1, "GESAMT", bg=TB, fg=DN, b=True)
    txt(ws, r, 2, f"{df_result['sid'].nunique():,} SIDs", bg=TB, fg=DN, it=True)
    for col, col_name in [(3, "user_per_sid"), (4, "unique_user_per_sid"),
                          (5, "user_total"),   (6, "unique_user_total"),
                          (7, "EMPFOHLEN_fuer_Simulation")]:
        tot(ws, r, col, int(df_result[col_name].fillna(0).sum()), nf=F_INT)
    r += 2

    # ── Erklärung der Metriken ──────────────────────────────────────────────
    h2(ws, r, 1, 7, "Erläuterung der 4 Metriken", bg=DN)
    r += 1
    erlaeuterungen = [
        ("(1) User# pro SID",
         "Alle Zeilen in der Rohdatei pro SID+ARE_BU. "
         "Enthält Duplikate (gleiche GID mehrfach auf einer SID, z.B. 5 Testuser). "
         "Verwendung: Nutzungsanalyse, Systemgröße."),
        ("(3) Unique User# pro SID",
         "Distinct GIDs innerhalb SID+ARE_BU. Duplikate auf der GLEICHEN SID werden nur einmal gezählt. "
         "EMPFOHLEN für Einfrierpreis-Berechnung (was der User zahlt). "
         "Gleiche GID auf VERSCHIEDENEN SIDs zählt für jede SID separat."),
        ("(2) User# total",
         "Alle Zeilen über alle SIDs hinweg pro ARE_BU. "
         "Höchste Zahl – für Gesamtauslastungsanalyse."),
        ("(4) Unique User# total global",
         "Distinct GIDs global pro ARE_BU (GID dedupliziert über alle SIDs). "
         "Basis für Szenario 2 Flat-Fee-Berechnung: eine GID = ein User global."),
        ("EMPFOHLEN für Simulation",
         f"= {'(3) Unique User# pro SID' if unique_schalter else '(1) User# pro SID'} "
         f"(Unique-Schalter: {'JA' if unique_schalter else 'NEIN'}). "
         "Diese Spalte direkt in Simulation_Sc1 als Werte einfügen."),
    ]
    for i, (metric, desc) in enumerate(erlaeuterungen):
        bg = LS if i % 2 == 0 else WH
        txt(ws, r, 1, metric, bg=bg, fg=DN, b=True)
        ws.merge_cells(start_row=r, start_column=2, end_row=r, end_column=7)
        cell = ws.cell(r, 2, desc)
        style(cell, bg=bg, fg="333333", wrap=True)
        ws.row_dimensions[r].height = 30
        r += 1

    ws.freeze_panes = "C7"

    # ── Sheet 2: SID_Pivot ────────────────────────────────────────────────────
    ws2 = wb.create_sheet("SID_Pivot")
    ws2.sheet_view.showGridLines = False
    ws2.tab_color = PT

    # Pivot: ARE_BU as rows, SIDs as columns, unique_user_per_sid as values
    pivot = (df_result
             .pivot_table(index="ARE_Business_BU",
                          columns="sid",
                          values="unique_user_per_sid",
                          aggfunc="sum",
                          fill_value=0))

    sids = list(pivot.columns)
    ws2.column_dimensions["A"].width = 32
    for j in range(len(sids)):
        ws2.column_dimensions[get_column_letter(j + 2)].width = 12
    ws2.column_dimensions[get_column_letter(len(sids) + 2)].width = 16  # total

    h1(ws2, 1, 1, len(sids) + 2,
       f"SID Pivot – Unique User# pro SID × ARE_Business_BU  |  {today}")
    r2 = 2
    note(ws2, r2, 1, len(sids) + 2,
         "Unique GIDs pro SID und ARE_BU-Kombination. "
         "Einfärben: Zellen > 0 = relevant für Einfrierpreis. "
         "Zeilen ohne Einträge auf einer SID = ARE ist nicht auf dieser SID.",
         fg=DN, h=22)
    r2 += 2

    # Headers
    ch(ws2, r2, 1, "ARE_Business_BU", bg=DN)
    for j, sid in enumerate(sids):
        ch(ws2, r2, j + 2, sid, bg=PT)
    ch(ws2, r2, len(sids) + 2, "TOTAL\nUnique/global", bg=SG, fg=DN)
    r2 += 1; pivot_start = r2

    for i, (are_bu, row_vals) in enumerate(pivot.iterrows()):
        bg = LS if i % 2 == 0 else WH
        txt(ws2, r2, 1, are_bu, bg=bg, fg=DN, b=True)
        row_total = 0
        for j, sid in enumerate(sids):
            v = int(row_vals.get(sid, 0))
            cell = ws2.cell(r2, j + 2, v if v > 0 else None)
            cell_bg = "E8F8F0" if v > 0 else bg
            style(cell, bg=cell_bg, ha="center",
                  nf=F_INT if v > 0 else None,
                  fg="006633" if v > 0 else DS)
            row_total += v
        # Unique total per ARE_BU from main result
        are_unique = df_result[df_result["ARE_Business_BU"] == are_bu]["unique_user_total"].iloc[0]
        cell_t = ws2.cell(r2, len(sids) + 2, int(are_unique or 0))
        style(cell_t, bg="E8F8F0", fg="006633", b=True, ha="center", nf=F_INT)
        r2 += 1

    # Column totals
    r2 += 1
    txt(ws2, r2, 1, "TOTAL", bg=TB, fg=DN, b=True)
    for j, sid in enumerate(sids):
        col_l = get_column_letter(j + 2)
        tot_val = int(pivot[sid].sum())
        tot(ws2, r2, j + 2, tot_val, nf=F_INT)
    grand = int(df_result.drop_duplicates(subset=["ARE_Business_BU"])["unique_user_total"].fillna(0).sum())
    tot(ws2, r2, len(sids) + 2, grand, nf=F_INT)

    ws2.freeze_panes = "B7"

    # ── Sheet 3: Statistik ────────────────────────────────────────────────────
    ws3 = wb.create_sheet("Statistik")
    ws3.sheet_view.showGridLines = False
    ws3.tab_color = DY

    ws3.column_dimensions["A"].width = 36
    ws3.column_dimensions["B"].width = 20

    h1(ws3, 1, 1, 2, f"Verarbeitungsstatistik  |  {today}")
    r3 = 3
    h2(ws3, r3, 1, 2, "Datenqualität & Kennzahlen")
    r3 += 1

    stat_rows = [
        ("Quelldatei",                           src_name),
        ("Verarbeitet am",                       today),
        ("Unique-Schalter",                      "JA (empfohlen)" if unique_schalter else "NEIN"),
        ("───────────────────────────────────", ""),
        ("Zeilen in Rohdatei",                   f"{stats['n_raw']:,}"),
        ("Davon ignoriert (leer/ARE_notallocated)", f"{stats['n_ignored']:,}"),
        ("Davon verarbeitet",                    f"{stats['n_processed']:,}"),
        ("───────────────────────────────────", ""),
        ("Distinct ARE_Business_BU",             f"{stats['n_are_bu']:,}"),
        ("Distinct SIDs",                        f"{stats['n_sid']:,}"),
        ("Distinct GIDs global",                 f"{stats['n_gid_global']:,}"),
        ("ARE_BU × SID Kombinationen",           f"{stats['n_combinations']:,}"),
        ("───────────────────────────────────", ""),
        ("Ø User# pro SID pro ARE_BU",          f"{stats['avg_user_per_sid']:.1f}"),
        ("Ø Unique User# pro ARE_BU",           f"{stats['avg_unique_per_are']:.1f}"),
        ("ARE_BU ohne SID-Zuordnung",           f"{stats['n_no_sid']:,}"),
    ]
    for i, (label, value) in enumerate(stat_rows):
        bg = LS if i % 2 == 0 else WH
        if "──" in label:
            ws3.merge_cells(start_row=r3, start_column=1, end_row=r3, end_column=2)
            ws3.cell(r3, 1, "").fill = PatternFill("solid", fgColor="E8E8E8")
            r3 += 1; continue
        txt(ws3, r3, 1, label, bg=bg, fg=DN, b=True)
        txt(ws3, r3, 2, value, bg=bg, ha="right")
        r3 += 1

    return wb


# ── Main ──────────────────────────────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(
        description="GID Data Processor – SAP User Count Aggregation")
    parser.add_argument("input_file",
                        help="Rohdaten-Datei (Excel .xlsx/.xls oder CSV)")
    parser.add_argument("--unique-schalter", choices=["ja", "nein"], default="ja",
                        help="Ja = Unique GID pro SID (empfohlen). Nein = alle Zeilen.")
    parser.add_argument("--col-gid", default=None,
                        help="Spaltenname GID falls nicht automatisch erkannt")
    parser.add_argument("--col-sid", default=None,
                        help="Spaltenname SID falls nicht automatisch erkannt")
    parser.add_argument("--col-position", default=None,
                        help="Spaltenname Position/ARE_BU falls nicht automatisch erkannt")
    parser.add_argument("--separator", default=None,
                        help="CSV Trennzeichen (default: automatisch)")
    args = parser.parse_args()

    unique_schalter = args.unique_schalter.lower() == "ja"
    input_file = args.input_file

    if not os.path.exists(input_file):
        print(f"✗ Datei nicht gefunden: {input_file}")
        sys.exit(1)

    ext = os.path.splitext(input_file)[1].lower()
    print(f"→ Lese: {input_file}")

    # Read file
    try:
        if ext in [".xlsx", ".xls", ".xlsm"]:
            df_raw = pd.read_excel(input_file, dtype=str)
        elif ext in [".csv", ".txt"]:
            sep = args.separator
            if sep is None:
                # Try to detect
                with open(input_file, "r", encoding="utf-8-sig", errors="replace") as f:
                    sample = f.read(2048)
                sep = ";" if sample.count(";") > sample.count(",") else ","
            df_raw = pd.read_csv(input_file, dtype=str, sep=sep,
                                 encoding="utf-8-sig", on_bad_lines="skip")
        else:
            print(f"✗ Unbekanntes Dateiformat: {ext}")
            sys.exit(1)
    except Exception as e:
        print(f"✗ Fehler beim Lesen: {e}")
        sys.exit(1)

    print(f"  → {len(df_raw):,} Zeilen, {len(df_raw.columns)} Spalten gelesen")
    print(f"  → Spalten: {list(df_raw.columns)}")

    # Map columns
    cols = list(df_raw.columns)
    gid_col = args.col_gid or find_col(cols, COL_ALIASES["gid"])
    sid_col = args.col_sid or find_col(cols, COL_ALIASES["sid"])
    pos_col = (args.col_position or
               find_col(cols, COL_ALIASES["position"]))

    missing = []
    if not gid_col:  missing.append("GID")
    if not sid_col:  missing.append("SID")
    if not pos_col:  missing.append("Position/ARE_BU")

    if missing:
        print(f"✗ Spalten nicht gefunden: {missing}")
        print(f"  Verfügbare Spalten: {cols}")
        print(f"  Hilfe: --col-gid SPALTENNAME --col-sid SPALTENNAME --col-position SPALTENNAME")
        sys.exit(1)

    print(f"  → GID: '{gid_col}' | SID: '{sid_col}' | Position: '{pos_col}'")

    # Rename to internal names
    df = df_raw[[gid_col, sid_col, pos_col]].copy()
    df.columns = ["gid", "sid", "position"]

    n_raw = len(df)
    df_filtered = df.copy()
    df_filtered = df_filtered.dropna(subset=["position"])
    df_filtered = df_filtered[
        ~df_filtered["position"].str.strip().isin(IGNORE_POSITION)
    ]
    df_filtered = df_filtered[df_filtered["position"].str.strip() != ""]
    n_processed = len(df_filtered)
    n_ignored = n_raw - n_processed

    print(f"  → {n_raw:,} Zeilen roh | {n_ignored:,} ignoriert | {n_processed:,} verarbeitet")

    if n_processed == 0:
        print("✗ Keine Daten nach Filterung. Spalten-Mapping prüfen.")
        sys.exit(1)

    # Compute
    print("→ Berechne 4 Metriken...")
    df_result = compute_metrics(df_filtered, unique_schalter)

    n_are_bu = df_result["ARE_Business_BU"].nunique()
    n_sid    = df_result["sid"].nunique()
    stats = {
        "n_raw":           n_raw,
        "n_ignored":       n_ignored,
        "n_processed":     n_processed,
        "n_are_bu":        n_are_bu,
        "n_sid":           n_sid,
        "n_gid_global":    df_filtered["gid"].nunique(),
        "n_combinations":  len(df_result),
        "avg_user_per_sid": df_result["user_per_sid"].mean(),
        "avg_unique_per_are": df_result["unique_user_per_sid"].mean(),
        "n_no_sid":        int((df_result["user_per_sid"] == 0).sum()),
    }
    print(f"  → {n_are_bu:,} ARE_BU | {n_sid:,} SIDs | {stats['n_combinations']:,} Kombinationen")

    # Build output
    print("→ Erstelle Ausgabe-Datei...")
    wb = build_output_excel(df_result, input_file, unique_schalter, stats)

    # Save
    date_str = datetime.now().strftime("%Y%m%d_%H%M")
    out_dir = os.path.dirname(os.path.abspath(input_file))
    out_file = os.path.join(out_dir, f"GID_Aggregiert_{date_str}.xlsx")
    wb.save(out_file)

    print(f"\n✓ Gespeichert: {out_file}")
    print(f"\n  NÄCHSTE SCHRITTE:")
    print(f"  1. {out_file} öffnen")
    print(f"  2. Tab 'GID_Aggregiert' → Spalte G (EMPFOHLEN) kopieren")
    print(f"  3. In Simulation_Sc1 → Zielzelle → Inhalte einfügen → NUR WERTE")
    print(f"  4. Simulation rechnet dann nicht mehr neu – bis zur nächsten Erhebung")
    return out_file


if __name__ == "__main__":
    main()
